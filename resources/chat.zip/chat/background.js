(function() {
	var count = 0;

	var posts = {};
	if ( localStorage.posts != undefined ) posts = localStorage.posts;
	else posts = { local: [], remote: [] };

	Array.prototype.diff = function(a) {
		return this.filter(function(i) {return !(a.indexOf(i) > -1);});
	};

	function request( url, data, success, error ) {
		$.ajax( "http://chat.stylemistake.com/"+url, {
			type: "GET",
			data: data,
			dataType: "json",
			success: function( data ) {
				if( data.status == "success" ) { success( data ); } else { error( data ); }
			},
			error: error
		});
	}

	function getMessageList( size, fun ) {
		request( 'chat/get', { type: 'list', size: size }, fun );
	}

	function setBadge( text ) {
		if ( text == 0 ) {
			chrome.browserAction.setBadgeText({ text: "" });
		} else {
			chrome.browserAction.setBadgeText({ text: ""+text });
		}
	}

	function push( remote ) {
		posts.local = posts.local.concat( remote );
	}

	function updateCounter( c ) {
		if ( c == undefined ) {
			setBadge( count = 0 );
			return false;
		} else {
			chrome.tabs.query( { url: "http://chat.stylemistake.com/", active: true }, function( tabs ) {
				if ( tabs != undefined && tabs[0] != undefined ) count = 0;
				else count += c;
				setBadge( count );
			});
			return true;
		}
	}

	(function updateChatlog() {
		getMessageList( (posts.local.length<5) ? 100 : 10, function( data ) {
			var ids = [];
			for (a in data.result) ids.push(data.result[a].id);
			ids.pop();
			posts.remote = ids.diff( posts.local );
			if ( posts.local.length != 0 ) {
				updateCounter( posts.remote.length );
			} else {
				updateCounter(0);
			}
			push( posts.remote );
		});
		setTimeout( updateChatlog, 15000 );
	}());

	setInterval( function() { updateCounter(0) }, 1000 );

	chrome.browserAction.onClicked.addListener( function() {
		chrome.tabs.create({url: "http://chat.stylemistake.com/"});
	});
}());